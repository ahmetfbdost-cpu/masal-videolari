"""XTTS-v2 seslendirme servisi (sunucu CPU'su). Seslendirme Standardı: yalnız onaylı ses örnekleri, cümle cümle üretim,
cümle arası 0,58 sn, -14 LUFS. POST /seslendir {"metin","ses","dil"} -> WAV"""
import hashlib
import os
import re
import subprocess
import tempfile
import threading
from pathlib import Path

import numpy as np
import soundfile as sf
from fastapi import FastAPI, HTTPException
from fastapi.responses import Response
from pydantic import BaseModel

ONAYLI = {"ahmet", "mia", "ses1", "ses3", "ses4", "ses6", "ses7", "ses8"}
SESLER = Path("/sesler")
ARA_SN = 0.58
app = FastAPI(title="ses", docs_url=None, redoc_url=None)
_kilit = threading.Lock()
_tts = None


ONBELLEK = Path("/modeller/onbellek")


def _model():
    global _tts
    if _tts is None:
        import torch
        torch.set_num_threads(os.cpu_count() or 4)  # tüm çekirdekler
        from TTS.api import TTS
        _tts = TTS("tts_models/multilingual/multi-dataset/xtts_v2").to("cpu")
    return _tts


def _cumle_sesi(tts, cumle: str, ornek: Path, dil: str) -> np.ndarray:
    """Aynı cümle (ör. 'İtalya'nın ünlü gazetesi X yazdı:') tekrar üretilmez, önbellekten gelir."""
    ONBELLEK.mkdir(parents=True, exist_ok=True)
    anahtar = hashlib.sha1(f"{ornek.name}|{dil}|{cumle}".encode()).hexdigest()
    yol = ONBELLEK / f"{anahtar}.npy"
    if yol.exists():
        return np.load(yol)
    ses = np.asarray(tts.tts(text=cumle, speaker_wav=str(ornek), language=dil), dtype=np.float32)
    np.save(yol, ses)
    return ses


class Istek(BaseModel):
    metin: str
    ses: str = "ahmet"
    dil: str = "tr"


def _cumleler(metin: str) -> list[str]:
    parca = [p.strip() for p in re.split(r"(?<=[.!?:])\s+", metin.strip()) if p.strip()]
    return [p if p[-1] in ".!?" else p.rstrip(":") + "." for p in parca]


@app.post("/seslendir")
def seslendir(i: Istek):
    if i.ses not in ONAYLI:
        raise HTTPException(400, "Onaylı olmayan ses")
    ornek = next((SESLER / f"{i.ses}{u}" for u in (".wav", ".mp3") if (SESLER / f"{i.ses}{u}").exists()), None)
    if not ornek:
        raise HTTPException(404, f"Ses örneği yok: /sesler/{i.ses}.wav")
    with _kilit:
        tts = _model()
        sr = tts.synthesizer.output_sample_rate
        parcalar = []
        for c in _cumleler(i.metin):
            parcalar.append(_cumle_sesi(tts, c, ornek, i.dil))
            parcalar.append(np.zeros(int(sr * ARA_SN), dtype=np.float32))
    ses = np.concatenate(parcalar[:-1]) if parcalar else np.zeros(sr, dtype=np.float32)
    with tempfile.TemporaryDirectory() as d:
        ham, son = Path(d) / "ham.wav", Path(d) / "son.wav"
        sf.write(ham, ses, sr)
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", str(ham), "-af", "loudnorm=I=-14:TP=-1.5", "-ar", "44100",
                        str(son)], check=True)
        return Response(son.read_bytes(), media_type="audio/wav")


@app.get("/saglik")
def saglik():
    return {"tamam": True, "sesler": sorted(p.stem for p in SESLER.glob("*") if p.stem in ONAYLI)}
