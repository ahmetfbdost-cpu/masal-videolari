"""Haber kümelerinden gönderi hazırlama, onay kuralı ve yayın zamanlaması."""
import json
import re
import logging
import time
import uuid
from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo

from . import ayarlar, denetim, ekran, isleme, kart, tasarim, metin, okunus, ozet, toplayicilar as tp, video, vt

log = logging.getLogger("yb.kuyruk")
TZ = ZoneInfo("Europe/Istanbul")


def _kume_haberleri(kume_id: str) -> list[dict]:
    hs = vt.sorgu("SELECT * FROM haberler WHERE kume_id=?", kume_id)
    harita = isleme.alan_oncelik()

    def agirlik(h):
        onc = h["oncelik"] if h["oncelik"] in ("P1", "P2", "P3") else harita.get(h["kaynak_alan"], "R")
        return (-isleme.AGIRLIK.get(onc, 1), h["yontem"] == "google_news", h["zaman"] or "")
    tekil, gorulen = [], set()
    for h in sorted(hs, key=agirlik):
        if h["kaynak_alan"] in gorulen:
            continue
        gorulen.add(h["kaynak_alan"])
        tekil.append(h)
    return tekil


def otomatik_onay_mi(kume: dict, sonuc: dict) -> bool:
    o = ayarlar.ayar()["oneri"]
    if not o.get("otomatik_onay"):
        return False
    if sonuc["iddia"] and not o.get("otomatik_onay_iddia"):
        return False
    if (kume.get("kaynak_sayisi") or 0) < o.get("otomatik_onay_min_kaynak", 2):
        return False
    return kalite_tamam(sonuc)


YABANCI = re.compile(r"\b(the|and|with|der|die|und|ist|el|los|las|que|il|della|het|een|les|des|est|não|para)\b", re.I)


def kalite_tamam(sonuc: dict) -> bool:
    """Otomatik yayın öncesi kontrol: güçlü model yazmış olmalı, metin Türk takımından bahsetmeli, yabancı cümle kalmamalı."""
    if sonuc.get("model") != "groq" and not ayarlar.ayar()["oneri"].get("yerel_model_otomatik", False):
        return False
    metin_ = f"{sonuc.get('baslik', '')} {sonuc.get('metin', '')}"
    if not metin.eslestir(metin_)[0]:
        return False
    govde = re.sub(r"https?://\S+|#\w+|Kaynak:.*", "", metin_)
    return len(YABANCI.findall(govde)) <= 2


def json_yaz(g: dict):
    (ayarlar.KUYRUK / f"{g['id']}.json").write_text(json.dumps(g, ensure_ascii=False, indent=2), encoding="utf-8")


def _link_ekle(metin: str, link: str) -> str:
    """Haberin linki etiketlerden önce, metnin en altına."""
    satirlar = metin.rstrip().split("\n")
    if satirlar and satirlar[-1].lstrip().startswith("#"):
        return "\n".join(satirlar[:-1]).rstrip() + f"\n\n🔗 Haberin linki: {link}\n\n" + satirlar[-1]
    return metin.rstrip() + f"\n\n🔗 Haberin linki: {link}"


_deneme: dict[str, int] = {}


def _atla(kume_id: str, neden: str):
    log.warning("Gönderi YAYINLANMAYACAK (%s): %s", kume_id, neden)
    with vt.islem() as c:
        c.execute("UPDATE kumeler SET durum='atlandi' WHERE id=?", (kume_id,))


def _tekrar(kume_id: str, neden: str, azami: int = 3):
    """Geçici hata: küme açık kalır, sonraki turda yeniden denenir; azami denemeden sonra atlanır."""
    _deneme[kume_id] = _deneme.get(kume_id, 0) + 1
    if _deneme[kume_id] >= azami:
        _atla(kume_id, f"{neden} ({azami} deneme)")
    else:
        log.warning("Yeniden denenecek (%s): %s", kume_id, neden)


def _ekran_al(link: str) -> bytes | None:
    for _ in range(2):
        e = ekran.ekran_goruntusu(link)
        if denetim.ekran_gecerli(e):
            return e
    return None


def gonderileri_hazirla(azami: int = 3) -> int:
    o = ayarlar.ayar()["oneri"]
    sinir = (datetime.now(timezone.utc) - timedelta(hours=24)).isoformat(timespec="seconds")
    adaylar = vt.sorgu("SELECT * FROM kumeler WHERE durum='acik' AND puan>=? AND guncelleme>? ORDER BY puan DESC LIMIT ?",
                       o.get("min_puan", 5), sinir, azami)
    hazir = 0
    for kume in adaylar:
        haberler = _kume_haberleri(kume["id"])
        if not haberler:
            continue
        sonuc = ozet.gonderi_uret(haberler)
        if sonuc is None:
            continue  # LLM erişilemedi: küme açık kalır, sonraki turda yeniden denenir
        if not sonuc["uygun"]:
            with vt.islem() as c:
                c.execute("UPDATE kumeler SET durum='atlandi' WHERE id=?", (kume["id"],))
            continue
        takimlar = json.loads(kume["takimlar"] or "[]")
        kaynaklar = [{"ad": e, "url": tp.google_news_coz(h["url"]) if i < 3 else h["url"], "baslik": h["baslik"]}
                     for i, (e, h) in enumerate(zip(sonuc["kaynak_etiketleri"], haberler))]
        link = kaynaklar[0]["url"] if kaynaklar else ""
        # ---- zorunlu denetimler: tazelik, içerik doğruluğu, sayfa görüntüsü
        taze, neden = denetim.taze_mi(link, haberler[0])
        if not taze:
            _atla(kume["id"], f"eski/tarihsiz haber: {neden} {link}")
            continue
        sonuc = denetim.metni_duzelt(sonuc)
        kaynak_metni = f"{haberler[0]['baslik']}\n{haberler[0].get('ozet') or ''}\n{tp.haber_metni(link, 4000)}"
        dogru, neden = denetim.icerik_denetle(sonuc, kaynak_metni)
        if not dogru:
            _tekrar(kume["id"], f"içerik kaynakla uyuşmuyor: {neden}", azami=2)
            continue
        ekran_ = _ekran_al(link)
        if not ekran_:
            _tekrar(kume["id"], f"sayfa ekran görüntüsü alınamadı: {link}")
            continue
        foto = next((b for b in (tp.haber_gorseli(k["url"]) for k in kaynaklar[:3]) if b), None)
        giris = sonuc.get("giris") or "Yabancı basın yazdı:"
        ilk_ad = (haberler[0].get("kaynak_ad") or "kaynak") if haberler else "kaynak"
        etiket0 = sonuc["kaynak_etiketleri"][0] if sonuc["kaynak_etiketleri"] else ilk_ad
        m_ = re.search(r"\(([^()]+)\)\s*$", etiket0)
        ulke = m_.group(1) if m_ else ""
        alan = metin.alan(link) or (haberler[0].get("kaynak_alan") if haberler else "") or ""
        if link and "news.google.com" not in link and link not in sonuc["metin"]:
            sonuc["metin"] = _link_ekle(sonuc["metin"], link)
        simdi = datetime.now(TZ)
        b_, oz = sonuc["baslik"], sonuc["ozet"]
        kapak = tasarim.kapak(giris, b_, ekran_, foto, ilk_ad, ulke, alan, takimlar, sonuc["tur"], sonuc["iddia"], simdi)
        detay_ = tasarim.detay(giris, b_, oz, foto or ekran_, ilk_ad, ulke, link, takimlar, simdi)
        gorsel, gorseller = kapak, [kapak.name, detay_.name]
        video_yolu = None
        if ayarlar.ayar().get("video", {}).get("aktif", True):
            k_d = tasarim.kapak(giris, b_, ekran_, foto, ilk_ad, ulke, alan, takimlar, sonuc["tur"], sonuc["iddia"], simdi, dikey=True)
            d_d = tasarim.detay(giris, b_, oz, foto or ekran_, ilk_ad, ulke, link, takimlar, simdi, dikey=True)
            video_yolu = video.video_uret([k_d, d_d], okunus.hazirla(f"{giris} {b_}"), takimlar, zorunlu_ses=True)
            if not video_yolu:
                _tekrar(kume["id"], "sesli video üretilemedi (seslendirme/müzik)")
                continue
        durum = "onayli" if otomatik_onay_mi(kume, sonuc) else "taslak"
        g = {"id": uuid.uuid4().hex[:12], "kume_id": kume["id"], "olusturma": vt.simdi(), "guncelleme": vt.simdi(), "durum": durum,
             "planlanan": None, "baslik": sonuc["baslik"], "metin": sonuc["metin"], "kisa_metin": sonuc["kisa_metin"],
             "etiketler": json.dumps(sonuc["etiketler"], ensure_ascii=False), "tur": sonuc["tur"], "iddia": int(sonuc["iddia"]),
             "kaynaklar": json.dumps(kaynaklar, ensure_ascii=False), "gorsel": gorsel.name, "gorseller": json.dumps(gorseller), "sonuc": None,
             "video": video_yolu.name if video_yolu else None, "video_basligi": sonuc.get("video_basligi"),
             "seslendirme": sonuc.get("seslendirme")}
        with vt.islem() as c:
            c.execute(f"INSERT INTO gonderiler ({','.join(g)}) VALUES ({','.join('?' * len(g))})", tuple(g.values()))
            c.execute("UPDATE kumeler SET durum='gonderi' WHERE id=?", (kume["id"],))
        json_yaz(g)
        hazir += 1
        log.info("Gönderi hazır (%s): %s", durum, sonuc["baslik"])
    if hazir:
        planla()
    return hazir


def _sessiz(t: datetime) -> bool:
    o = ayarlar.ayar()["oneri"]
    b, s = o.get("sessiz_saat_baslangic", 1), o.get("sessiz_saat_bitis", 7)
    if b is None or s is None or b == s or b > 23:  # sessiz saat kapalı
        return False
    return b <= t.hour < s if b < s else (t.hour >= b or t.hour < s)


def planla() -> int:
    """Onaylı ama zamanı atanmamış gönderilere yayın saati verir (aralık, günlük sınır, sessiz saatler)."""
    o = ayarlar.ayar()["oneri"]
    aralik = timedelta(minutes=o.get("gonderi_arasi_dakika", 60))
    azami = o.get("gunluk_azami_gonderi", 8)
    bekleyen = vt.sorgu("SELECT id FROM gonderiler WHERE durum='onayli' AND planlanan IS NULL ORDER BY olusturma")
    if not bekleyen:
        return 0
    dolu = [datetime.fromisoformat(r["planlanan"]).astimezone(TZ) for r in
            vt.sorgu("SELECT planlanan FROM gonderiler WHERE planlanan IS NOT NULL AND durum IN ('onayli','yayinlandi','kuru','elle')")]
    t = max([datetime.now(TZ)] + [d + aralik for d in dolu])
    for g in bekleyen:
        while True:
            if _sessiz(t):
                t = t.replace(hour=ayarlar.ayar()["oneri"].get("sessiz_saat_bitis", 7), minute=0, second=0, microsecond=0)
                if t < datetime.now(TZ):
                    t += timedelta(days=1)
                continue
            if sum(1 for d in dolu if d.date() == t.date()) >= azami:
                t = (t + timedelta(days=1)).replace(hour=o.get("sessiz_saat_bitis", 7), minute=0, second=0, microsecond=0)
                continue
            break
        with vt.islem() as c:
            c.execute("UPDATE gonderiler SET planlanan=?, guncelleme=? WHERE id=?", (t.isoformat(timespec="minutes"), vt.simdi(), g["id"]))
        dolu.append(t)
        t += aralik
    return len(bekleyen)


def durum_degistir(gid: str, durum: str, **alanlar):
    alanlar["durum"] = durum
    alanlar["guncelleme"] = vt.simdi()
    if durum == "onayli":
        alanlar.setdefault("planlanan", None)
    with vt.islem() as c:
        c.execute(f"UPDATE gonderiler SET {', '.join(f'{k}=?' for k in alanlar)} WHERE id=?", (*alanlar.values(), gid))
    g = vt.sorgu("SELECT * FROM gonderiler WHERE id=?", gid)
    if g:
        json_yaz(g[0])
    if durum == "onayli":
        planla()


def zamani_gelenler() -> list[dict]:
    simdi = datetime.now(TZ).isoformat(timespec="minutes")
    return vt.sorgu("SELECT * FROM gonderiler WHERE durum='onayli' AND planlanan IS NOT NULL AND planlanan<=? ORDER BY planlanan", simdi)


def temizlik() -> int:
    """saklama_gun'den eski görsel/video dosyalarını siler (onay bekleyen ve sıradaki gönderilerinkiler korunur)."""
    gun = (ayarlar.ayar().get("video") or {}).get("saklama_gun", 30)
    sinir = time.time() - gun * 86400
    korunan = {r[k] for r in vt.sorgu("SELECT gorsel, video FROM gonderiler WHERE durum IN ('taslak','onayli','elle')")
               for k in ("gorsel", "video") if r[k]}
    n = 0
    for p in ayarlar.GORSEL.iterdir():
        if p.is_file() and p.name not in korunan and p.stat().st_mtime < sinir:
            p.unlink(missing_ok=True)
            n += 1
    return n
