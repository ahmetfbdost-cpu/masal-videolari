"""Platformlara yayın: Instagram (Reels), YouTube (Shorts), TikTok; isteğe bağlı Telegram, Facebook, Threads, Bluesky.

Kimlik bilgileri panelden (Bağlantılar) ya da .env dosyasından okunur; eksik olan platform atlanır.
kuru_calisma açıkken hiçbir platforma istek gitmez; gönderi 'kuru' olarak işaretlenir.
Bir platform hata verirse "Şimdi yayınla" yalnızca eksik platformları yeniden dener.
"""
import json
import logging
import re
import time
from datetime import datetime, timezone

import httpx

from . import ayarlar, kimlik, kuyruk, vt, yetki
from .ayarlar import ortam

log = logging.getLogger("yb.yayin")


def _gorsel_yolu(g: dict):
    return ayarlar.GORSEL / g["gorsel"]


def _kaynak_linkleri(g: dict) -> list[dict]:
    try:
        return json.loads(g.get("kaynaklar") or "[]")
    except json.JSONDecodeError:
        return []


def _uzun_metin(g: dict, link: bool = True) -> str:
    metin = g["metin"]
    if link:
        linkler = [k["url"] for k in _kaynak_linkleri(g)[:2] if k.get("url") and k["url"] not in metin]
        if linkler:
            metin += "\n\n🔗 " + "\n🔗 ".join(linkler)
    return metin


# ---------------------------------------------------------------- Telegram
def telegram(g: dict) -> dict:
    token, sohbet = kimlik.al("TELEGRAM_BOT_TOKEN"), kimlik.al("TELEGRAM_KANAL")
    if not token or not sohbet:
        return {"atlandi": "TELEGRAM_BOT_TOKEN/TELEGRAM_KANAL yok"}
    metin = _uzun_metin(g)
    with open(_gorsel_yolu(g), "rb") as f:
        r = httpx.post(f"https://api.telegram.org/bot{token}/sendPhoto",
                       data={"chat_id": sohbet, "caption": metin[:1024]}, files={"photo": f}, timeout=60)
    r.raise_for_status()
    if len(metin) > 1024:
        httpx.post(f"https://api.telegram.org/bot{token}/sendMessage", data={"chat_id": sohbet, "text": metin[1024:4096]}, timeout=30)
    return {"tamam": True, "mesaj_id": r.json().get("result", {}).get("message_id")}


# ---------------------------------------------------------------- Meta (Facebook / Instagram)
def _graph() -> str:
    return f"https://graph.facebook.com/{ayarlar.ayar()['yayin'].get('meta_api_surum', 'v24.0')}"


def facebook(g: dict) -> dict:
    sayfa, token = kimlik.al("FACEBOOK_SAYFA_ID"), kimlik.al("FACEBOOK_SAYFA_TOKEN")
    if not sayfa or not token:
        return {"atlandi": "FACEBOOK_SAYFA_ID/FACEBOOK_SAYFA_TOKEN yok"}
    with open(_gorsel_yolu(g), "rb") as f:
        r = httpx.post(f"{_graph()}/{sayfa}/photos", data={"caption": _uzun_metin(g), "access_token": token}, files={"source": f}, timeout=90)
    r.raise_for_status()
    return {"tamam": True, "gonderi_id": r.json().get("post_id") or r.json().get("id")}


_tunel = {"adres": None, "zaman": 0.0}


def genel_taban() -> str | None:
    """Herkese açık medya adresi: ayardaki sabit adres, yoksa Cloudflare hızlı tünelinin o anki adresi."""
    y = ayarlar.ayar()["yayin"]
    sabit = y.get("genel_url_tabani") or y.get("gorsel_genel_url_tabani") or ortam("GENEL_URL_TABANI") or ortam("GORSEL_GENEL_URL_TABANI")
    if sabit:
        return sabit.rstrip("/")
    if _tunel["adres"] and time.time() - _tunel["zaman"] < 300:
        return _tunel["adres"]
    metrik = (y.get("tunel_metrik_url") or "http://tunel:20241").rstrip("/")
    adres = None
    try:
        r = httpx.get(f"{metrik}/quicktunnel", timeout=5)
        if r.status_code == 200 and r.json().get("hostname"):
            adres = "https://" + r.json()["hostname"]
    except Exception:
        pass
    if not adres:
        try:
            m = re.search(r'userHostname="(https://[^"]+)"', httpx.get(f"{metrik}/metrics", timeout=5).text)
            adres = m.group(1) if m else None
        except Exception:
            pass
    _tunel.update(adres=adres.rstrip("/") if adres else None, zaman=time.time())
    return _tunel["adres"]


def genel_url(dosya: str, dene: bool = False) -> str | None:
    taban = genel_taban()
    if not taban or not dosya:
        return None
    url = f"{taban}/genel/{dosya}"
    if dene:  # platform çekmeden önce adresin dışarıdan açıldığını doğrula
        try:
            r = httpx.head(url, timeout=20, follow_redirects=True)
            if r.status_code >= 400:
                raise RuntimeError(f"{r.status_code}")
        except Exception as e:
            _tunel.update(adres=None, zaman=0)
            raise RuntimeError(f"Herkese açık medya adresi açılmıyor ({url}): {e}. Tünel konteynerini kontrol et: docker logs yb-tunel")
    return url


def genel_gorsel_url(g: dict) -> str:
    """Görsel gönderiler (Threads, Instagram görsel modu) için herkese açık adres; tünel yoksa Facebook sayfası üzerinden."""
    url = genel_url(g["gorsel"], dene=True) if genel_taban() else None
    if url:
        return url
    sayfa, token = kimlik.al("FACEBOOK_SAYFA_ID"), kimlik.al("FACEBOOK_SAYFA_TOKEN")
    if not sayfa or not token:
        raise RuntimeError("Görsel için herkese açık adres yok: tünel çalışmıyor ve Facebook sayfa bilgisi yok")
    with open(_gorsel_yolu(g), "rb") as f:  # yayımlanmamış sayfa fotoğrafı olarak yükle, CDN adresini al
        r = httpx.post(f"{_graph()}/{sayfa}/photos", data={"published": "false", "access_token": token}, files={"source": f}, timeout=90)
    _kontrol(r, "Facebook")
    foto = r.json()["id"]
    r2 = httpx.get(f"{_graph()}/{foto}", params={"fields": "images", "access_token": token}, timeout=30)
    _kontrol(r2, "Facebook")
    return r2.json()["images"][0]["source"]


def _kontrol(r: httpx.Response, ne: str):
    if r.status_code >= 400:
        raise RuntimeError(f"{ne} {r.status_code}: {r.text[:400]}")


def _ig_bekle(taban: str, kap: str, token: str, video: bool):
    for _ in range(72 if video else 12):  # medya işlenene kadar bekle (video en çok ~6 dk)
        d = httpx.get(f"{taban}/{kap}", params={"fields": "status_code,status", "access_token": token}, timeout=30).json()
        kod = d.get("status_code")
        if kod == "FINISHED" or (kod is None and not video):
            return
        if kod in ("ERROR", "EXPIRED"):
            raise RuntimeError(f"Instagram medya hatası: {d}")
        time.sleep(5)
    raise RuntimeError("Instagram medyayı zamanında işleyemedi")


def _ig_kap(taban: str, hesap: str, token: str, veri: dict) -> str:
    r = httpx.post(f"{taban}/{hesap}/media", data=dict(veri, access_token=token), timeout=90)
    _kontrol(r, "Instagram")
    return r.json()["id"]


def instagram(g: dict) -> dict:
    hesap, token = kimlik.al("INSTAGRAM_HESAP_ID"), yetki.instagram_jeton()
    if not hesap or not token:
        return {"elle": True, "not": "Instagram bağlı değil: videoyu indirip elle paylaş ya da panel > Bağlantılar"}
    taban = yetki.ig_taban()
    tur = ayarlar.ayar()["yayin"].get("instagram_tur", "karusel")
    try:
        slaytlar = json.loads(g.get("gorseller") or "[]")
    except json.JSONDecodeError:
        slaytlar = []
    aciklama = g["metin"][:2200]
    if tur == "karusel" and slaytlar:
        # 1. slayt: sesli video (yabancı haberin sayfa görüntüsüyle başlar, seslendirme + fon müziği); sonra detay görseli
        cocuklar = []
        if g.get("video"):
            v = _ig_kap(taban, hesap, token, {"media_type": "VIDEO", "video_url": genel_url(g["video"], dene=True) or "",
                                              "is_carousel_item": "true"})
            _ig_bekle(taban, v, token, True)
            cocuklar.append(v)
            slaytlar = slaytlar[1:]
        for ad in slaytlar[:9]:
            k = _ig_kap(taban, hesap, token, {"image_url": genel_url(ad, dene=True) or "", "is_carousel_item": "true"})
            _ig_bekle(taban, k, token, False)
            cocuklar.append(k)
        if len(cocuklar) < 2:
            raise RuntimeError("Karusel için en az 2 öğe gerekli")
        kap = _ig_kap(taban, hesap, token, {"media_type": "CAROUSEL", "children": ",".join(cocuklar), "caption": aciklama})
        _ig_bekle(taban, kap, token, False)
        cesit = "karusel"
    elif tur in ("reels", "karusel") and g.get("video"):
        url = genel_url(g["video"], dene=True)
        if not url:
            raise RuntimeError("Reels için herkese açık video adresi yok (tünel çalışıyor mu? docker logs yb-tunel)")
        kap = _ig_kap(taban, hesap, token, {"media_type": "REELS", "video_url": url, "share_to_feed": "true", "caption": aciklama})
        _ig_bekle(taban, kap, token, True)
        cesit = "reels"
    else:
        kap = _ig_kap(taban, hesap, token, {"image_url": genel_gorsel_url(g), "caption": aciklama})
        _ig_bekle(taban, kap, token, False)
        cesit = "gorsel"
    r = httpx.post(f"{taban}/{hesap}/media_publish", data={"creation_id": kap, "access_token": token}, timeout=90)
    _kontrol(r, "Instagram")
    medya = r.json()["id"]
    linkler = [k["url"] for k in _kaynak_linkleri(g)[:2] if k.get("url")]
    if linkler:  # açıklamadaki link tıklanmadığı için kaynak linki ilk yoruma
        try:
            httpx.post(f"{taban}/{medya}/comments", data={"message": "Haberin linki: " + " | ".join(linkler), "access_token": token},
                       timeout=30)
        except Exception:
            pass
    return {"tamam": True, "medya_id": medya, "tur": cesit}


# ---------------------------------------------------------------- YouTube (Shorts)
def _yt_temiz(metin: str) -> str:
    return metin.replace("<", "‹").replace(">", "›").strip()


def youtube(g: dict) -> dict:
    if not kimlik.var("YOUTUBE_CLIENT_ID", "YOUTUBE_CLIENT_SECRET", "YOUTUBE_REFRESH_TOKEN"):
        return {"elle": True, "not": "YouTube bağlı değil: videoyu indirip elle paylaş ya da panel > Bağlantılar"}
    if not g.get("video"):
        return {"atlandi": "video yok"}
    y = ayarlar.ayar()["yayin"]
    yol = ayarlar.GORSEL / g["video"]
    baslik = _yt_temiz(g.get("video_basligi") or g["baslik"])[:100]
    if "#shorts" not in baslik.lower() and len(baslik) <= 91:
        baslik += " #Shorts"
    etiketler, toplam = [], 0
    for e in json.loads(g.get("etiketler") or "[]") + ["yabancı basın", "Türk futbolu", "spor haberleri"]:
        e = e.lstrip("#").strip()
        if e and toplam + len(e) + 3 <= 450:
            etiketler.append(e)
            toplam += len(e) + 3
    govde = {"snippet": {"title": baslik, "description": _yt_temiz(_uzun_metin(g))[:4900], "tags": etiketler,
                         "categoryId": str(y.get("youtube_kategori", "17")), "defaultLanguage": "tr", "defaultAudioLanguage": "tr"},
             "status": {"privacyStatus": y.get("youtube_gizlilik", "private"), "selfDeclaredMadeForKids": False, "embeddable": True}}
    token = yetki.youtube_erisim()
    boyut = yol.stat().st_size
    r = httpx.post("https://www.googleapis.com/upload/youtube/v3/videos", params={"uploadType": "resumable", "part": "snippet,status"},
                   headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json; charset=UTF-8",
                            "X-Upload-Content-Length": str(boyut), "X-Upload-Content-Type": "video/mp4"},
                   content=json.dumps(govde, ensure_ascii=False).encode("utf-8"), timeout=60)
    _kontrol(r, "YouTube")
    r = httpx.put(r.headers["Location"], content=yol.read_bytes(), headers={"Authorization": f"Bearer {token}", "Content-Type": "video/mp4"},
                  timeout=900)
    _kontrol(r, "YouTube yükleme")
    d = r.json()
    return {"tamam": True, "video_id": d["id"], "url": f"https://youtube.com/shorts/{d['id']}",
            "gizlilik": (d.get("status") or {}).get("privacyStatus")}


# ---------------------------------------------------------------- TikTok
def _tt_kontrol(d: dict, ne: str) -> dict:
    hata = d.get("error") or {}
    if hata.get("code", "ok") != "ok":
        raise RuntimeError(f"TikTok {ne}: {hata.get('code')} {hata.get('message', '')[:200]}")
    return d.get("data") or {}


def tiktok(g: dict) -> dict:
    mod = ayarlar.ayar()["yayin"].get("tiktok_mod", "elle")
    if not g.get("video"):
        return {"atlandi": "video yok"}
    if mod == "elle" or not kimlik.var("TIKTOK_CLIENT_KEY", "TIKTOK_CLIENT_SECRET", "TIKTOK_REFRESH_TOKEN"):
        return {"elle": True, "not": "Panelden videoyu indir, metni kopyala, TikTok'ta paylaş"}
    yol = ayarlar.GORSEL / g["video"]
    veri = yol.read_bytes()
    boyut = len(veri)
    parca, adet = (boyut, 1) if boyut <= 64 * 1024 * 1024 else (10 * 1024 * 1024, boyut // (10 * 1024 * 1024))
    kaynak = {"source": "FILE_UPLOAD", "video_size": boyut, "chunk_size": parca, "total_chunk_count": adet}
    bas = {"Authorization": f"Bearer {yetki.tiktok_erisim()}", "Content-Type": "application/json; charset=UTF-8"}
    api = yetki.TT_API
    if mod == "dogrudan":
        bilgi = _tt_kontrol(httpx.post(f"{api}/post/publish/creator_info/query/", headers=bas, json={}, timeout=30).json(), "hesap bilgisi")
        secenek = bilgi.get("privacy_level_options") or ["SELF_ONLY"]
        gizlilik = ayarlar.ayar()["yayin"].get("tiktok_gizlilik", "SELF_ONLY")
        gizlilik = gizlilik if gizlilik in secenek else ("SELF_ONLY" if "SELF_ONLY" in secenek else secenek[0])
        govde = {"post_info": {"title": g["metin"][:2200], "privacy_level": gizlilik, "disable_duet": False, "disable_comment": False,
                               "disable_stitch": False, "video_cover_timestamp_ms": 1000}, "source_info": kaynak}
        ilk = _tt_kontrol(httpx.post(f"{api}/post/publish/video/init/", headers=bas, json=govde, timeout=60).json(), "başlatma")
    else:  # taslak: video TikTok uygulamasındaki gelen kutusuna düşer, metni ekleyip sen paylaşırsın
        ilk = _tt_kontrol(httpx.post(f"{api}/post/publish/inbox/video/init/", headers=bas, json={"source_info": kaynak}, timeout=60).json(),
                          "başlatma")
    for i in range(adet):
        bas_b = i * parca
        son_b = boyut - 1 if i == adet - 1 else bas_b + parca - 1
        r = httpx.put(ilk["upload_url"], content=veri[bas_b:son_b + 1], timeout=900,
                      headers={"Content-Type": "video/mp4", "Content-Range": f"bytes {bas_b}-{son_b}/{boyut}"})
        _kontrol(r, "TikTok yükleme")
    durum = None
    for _ in range(24):
        d = _tt_kontrol(httpx.post(f"{api}/post/publish/status/fetch/", headers=bas, json={"publish_id": ilk["publish_id"]}, timeout=30).json(),
                        "durum")
        durum = d.get("status")
        if durum in ("PUBLISH_COMPLETE", "SEND_TO_USER_INBOX", "FAILED"):
            break
        time.sleep(5)
    if durum == "FAILED":
        raise RuntimeError(f"TikTok yayını başarısız: {d.get('fail_reason')}")
    return {"tamam": True, "publish_id": ilk["publish_id"], "durum": durum, "mod": mod}


# ---------------------------------------------------------------- Threads
def threads(g: dict) -> dict:
    kullanici, token = kimlik.al("THREADS_KULLANICI_ID"), kimlik.al("THREADS_TOKEN")
    if not kullanici or not token:
        return {"atlandi": "THREADS_KULLANICI_ID/THREADS_TOKEN yok"}
    taban = "https://graph.threads.net/v1.0"
    metin = g["kisa_metin"]
    linkler = [k["url"] for k in _kaynak_linkleri(g)[:1] if k.get("url")]
    if linkler and len(metin) + len(linkler[0]) + 2 <= 500:
        metin += "\n\n" + linkler[0]
    r = httpx.post(f"{taban}/{kullanici}/threads",
                   data={"media_type": "IMAGE", "image_url": genel_gorsel_url(g), "text": metin[:500], "access_token": token}, timeout=60)
    r.raise_for_status()
    time.sleep(20)  # Threads kapsayıcının işlenmesi için bekleme önerir
    r = httpx.post(f"{taban}/{kullanici}/threads_publish", data={"creation_id": r.json()["id"], "access_token": token}, timeout=60)
    r.raise_for_status()
    return {"tamam": True, "gonderi_id": r.json().get("id")}


# ---------------------------------------------------------------- Bluesky
def bluesky(g: dict) -> dict:
    tanimlayici, sifre = kimlik.al("BLUESKY_KULLANICI"), kimlik.al("BLUESKY_UYGULAMA_SIFRESI")
    if not tanimlayici or not sifre:
        return {"atlandi": "BLUESKY_KULLANICI/BLUESKY_UYGULAMA_SIFRESI yok"}
    pds = ortam("BLUESKY_SUNUCU", "https://bsky.social")
    oturum = httpx.post(f"{pds}/xrpc/com.atproto.server.createSession", json={"identifier": tanimlayici, "password": sifre}, timeout=30)
    oturum.raise_for_status()
    jwt, did = oturum.json()["accessJwt"], oturum.json()["did"]
    bas = {"Authorization": f"Bearer {jwt}"}
    blob = httpx.post(f"{pds}/xrpc/com.atproto.repo.uploadBlob", content=_gorsel_yolu(g).read_bytes(),
                      headers={**bas, "Content-Type": "image/png"}, timeout=60)
    blob.raise_for_status()
    metin = g["kisa_metin"]
    linkler = [k["url"] for k in _kaynak_linkleri(g)[:1] if k.get("url")]
    if linkler and len(metin) + len(linkler[0]) + 1 <= 300:
        metin += "\n" + linkler[0]
    metin = metin[:300]
    facets = []
    for m in re.finditer(r"https?://\S+", metin):
        bas_b = len(metin[: m.start()].encode("utf-8"))
        facets.append({"index": {"byteStart": bas_b, "byteEnd": bas_b + len(m.group(0).encode("utf-8"))},
                       "features": [{"$type": "app.bsky.richtext.facet#link", "uri": m.group(0)}]})
    kayit = {"$type": "app.bsky.feed.post", "text": metin, "createdAt": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
             "langs": ["tr"], "embed": {"$type": "app.bsky.embed.images", "images": [{"alt": g["baslik"], "image": blob.json()["blob"]}]}}
    if facets:
        kayit["facets"] = facets
    r = httpx.post(f"{pds}/xrpc/com.atproto.repo.createRecord", headers=bas,
                   json={"repo": did, "collection": "app.bsky.feed.post", "record": kayit}, timeout=30)
    r.raise_for_status()
    return {"tamam": True, "uri": r.json().get("uri")}


PLATFORMLAR = {"instagram": instagram, "youtube": youtube, "tiktok": tiktok, "telegram": telegram, "facebook": facebook,
               "threads": threads, "bluesky": bluesky}


def kuru_mu() -> bool:
    """Paneldeki 'Canlı yayın' düğmesi ayar dosyasını ezer."""
    panel = vt.durum_al("ayar:kuru_calisma")
    return bool(ayarlar.ayar()["yayin"].get("kuru_calisma", True) if panel is None else panel)


def yayinla(g: dict) -> dict:
    y = ayarlar.ayar()["yayin"]
    if kuru_mu():
        sonuc = {"kuru_calisma": True, "platformlar": y.get("platformlar", [])}
        kuyruk.durum_degistir(g["id"], "kuru", sonuc=json.dumps(sonuc, ensure_ascii=False))
        return sonuc
    try:
        onceki = json.loads(g.get("sonuc") or "{}")
    except json.JSONDecodeError:
        onceki = {}
    sonuc = {}
    for ad in y.get("platformlar", []):
        f = PLATFORMLAR.get(ad)
        if not f:
            continue
        eski = onceki.get(ad) if isinstance(onceki, dict) else None
        if isinstance(eski, dict) and eski.get("tamam"):
            sonuc[ad] = eski  # daha önce başarılı: tekrar gönderme
            continue
        try:
            sonuc[ad] = f(g)
        except Exception as e:
            log.warning("%s yayın hatası: %s", ad, e)
            sonuc[ad] = {"hata": str(e)[:400]}
    kuyruk.durum_degistir(g["id"], sonuc_durumu(sonuc), sonuc=json.dumps(sonuc, ensure_ascii=False))
    return sonuc


def sonuc_durumu(sonuc: dict) -> str:
    """hata varsa 'hata' (dikkat ister) · elle paylaşılacak kaldıysa 'elle' (yapılacaklar) · en az biri yayınlandıysa 'yayinlandi'."""
    degerler = [v for v in sonuc.values() if isinstance(v, dict)]
    if any(v.get("hata") for v in degerler):
        return "hata"
    if any(v.get("elle") and not v.get("tamam") for v in degerler):
        return "elle"
    return "yayinlandi" if any(v.get("tamam") for v in degerler) else "hata"


def elle_tamam(gid: str, platform: str):
    """Panelde 'Paylaştım' düğmesi: elle paylaşılan platformu tamamlandı say."""
    g = vt.sorgu("SELECT * FROM gonderiler WHERE id=?", gid)
    if not g:
        return
    try:
        sonuc = json.loads(g[0]["sonuc"] or "{}")
    except json.JSONDecodeError:
        sonuc = {}
    if not isinstance(sonuc, dict) or sonuc.get("kuru_calisma"):
        sonuc = {}
    sonuc[platform] = {"tamam": True, "elle": True, "zaman": vt.simdi()}
    kuyruk.durum_degistir(gid, sonuc_durumu(sonuc), sonuc=json.dumps(sonuc, ensure_ascii=False))


def yayin_turu() -> int:
    n = 0
    for g in kuyruk.zamani_gelenler():  # zamanı gelen hepsi: yabancı basından sonra en hızlı biz çıkalım
        yayinla(g)
        n += 1
    vt.durum_yaz("son_yayin_turu", vt.simdi())
    return n
