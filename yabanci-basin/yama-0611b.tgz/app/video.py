"""Dikey kısa video (Shorts / Reels / TikTok), sunucuda CPU ile FFmpeg.

Akış: kanca karesi (büyük başlık, ~3,5 sn) → yumuşak geçiş → tam haber kartı (yavaş yakınlaşma) → son.
Seslendirme varsayılan kapalı; açıldığında Seslendirme Standardına uygun yerel motor (XTTS-v2, onaylı sesler) çağrılır.
"""
import logging
import subprocess
import uuid
from datetime import datetime
from pathlib import Path

import httpx

from . import ayarlar

log = logging.getLogger("yb.video")
FPS = 30


def seslendir(metin: str) -> Path | None:
    """POST {url} JSON {"metin", "ses", "dil"} -> WAV baytları. Kapalıysa ya da hata olursa None (video sessiz üretilir)."""
    s = ayarlar.ayar().get("ses", {}) or {}
    if not s.get("aktif") or not s.get("url") or not metin:
        return None
    try:
        r = httpx.post(s["url"], json={"metin": metin, "ses": s.get("ses", "ahmet"), "dil": "tr"}, timeout=s.get("zaman_asimi_sn", 300))
        r.raise_for_status()
        yol = ayarlar.GORSEL / f"ses-{uuid.uuid4().hex[:10]}.wav"
        yol.write_bytes(r.content)
        return yol
    except Exception as e:
        log.warning("Seslendirme alınamadı, video sessiz üretilecek: %s", e)
        return None


def _sure(ses: Path) -> float:
    try:
        cikti = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", str(ses)],
                               capture_output=True, text=True, timeout=30).stdout.strip()
        return float(cikti)
    except Exception:
        return 0.0


def _yakinlas(i: int, saniye: float, hedef: float) -> str:
    kare = max(int(round(saniye * FPS)), 1)
    adim = (hedef - 1) / kare
    return (f"[{i}:v]scale=2160:-2,zoompan=z='min(zoom+{adim:.6f},{hedef})':d={kare}:x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':"
            f"s=1080x1920:fps={FPS},setsar=1,format=yuv420p[v{i}]")


MUZIK_UZANTI = (".mp3", ".m4a", ".wav", ".ogg")


def fon_muzigi(takimlar: list[str] | None) -> Path | None:
    """config/muzik/<takim>.mp3 (ör. galatasaray.mp3, fenerbahce.mp3); yoksa config/muzik/varsayilan.mp3; o da yoksa müziksiz."""
    klasor = ayarlar.CONFIG / "muzik"
    for ad in list(takimlar or []) + ["varsayilan"]:
        for uz in MUZIK_UZANTI:
            yol = klasor / f"{ad}{uz}"
            if yol.is_file():
                return yol
    return None


def video_uret(sahneler: list[Path] | Path, seslendirme_metni: str = "", takimlar: list[str] | None = None,
              zorunlu_ses: bool = False) -> Path | None:
    """sahneler: [kanca_karesi, dikey_kart] ya da tek kare. Takımın müzik dosyası varsa fon müziği olarak eklenir."""
    if isinstance(sahneler, Path):
        sahneler = [sahneler]
    sahneler = [s for s in sahneler if s][:2]
    if not sahneler:
        return None
    v = ayarlar.ayar().get("video", {}) or {}
    toplam = float(v.get("sure_sn", 13))
    ses = seslendir(seslendirme_metni)
    if zorunlu_ses and (not ses or not fon_muzigi(takimlar)):
        log.warning("Sesli video üretilmedi: %s", "seslendirme yok" if not ses else "müzik dosyası yok")
        return None
    if ses:
        toplam = max(toplam, _sure(ses) + 1.2)
    gecis = 0.5
    filtreler = []
    if len(sahneler) == 1:
        filtreler.append(_yakinlas(0, toplam, 1.06))
        son = "v0"
    else:
        kanca = float(v.get("kanca_sn", 3.5))
        filtreler.append(_yakinlas(0, kanca, 1.10))
        filtreler.append(_yakinlas(1, toplam - kanca + gecis, 1.05))
        filtreler.append(f"[v0][v1]xfade=transition=fade:duration={gecis}:offset={kanca - gecis:.2f}[vx]")
        son = "vx"
    yol = ayarlar.GORSEL / f"{datetime.now():%Y%m%d}-{uuid.uuid4().hex[:12]}.mp4"
    komut = ["ffmpeg", "-y", "-loglevel", "error"]
    for s in sahneler:
        komut += ["-i", str(s)]
    muzik = fon_muzigi(takimlar) if v.get("muzik", True) else None
    n = len(sahneler)
    komut += ["-i", str(ses)] if ses else ["-f", "lavfi", "-i", "anullsrc=r=44100:cl=stereo"]
    ses_cikis = f"{n}:a"
    if muzik:  # müzik: konuşma varsa kısık (-18 dB), yoksa -10 dB; girişte ve sonda yumuşak geçiş
        komut += ["-stream_loop", "-1", "-i", str(muzik)]
        sev = float(v.get("muzik_seviye_konusmali" if ses else "muzik_seviye", 0.13 if ses else 0.6))
        filtreler.append(f"[{n + 1}:a]atrim=0:{toplam:.2f},asetpts=PTS-STARTPTS,volume={sev},afade=t=in:d=0.8,"
                         f"afade=t=out:st={max(toplam - 1.5, 0):.2f}:d=1.5[mz]")
        filtreler.append(f"[{n}:a][mz]amix=inputs=2:duration=longest:normalize=0,aresample=44100[ax]")
        ses_cikis = "[ax]"
    komut += ["-filter_complex", ";".join(filtreler), "-map", f"[{son}]", "-map", ses_cikis, "-t", f"{toplam:.2f}",
              "-c:v", "libx264", "-preset", "veryfast", "-crf", str(v.get("crf", 21)), "-r", str(FPS),
              "-c:a", "aac", "-b:a", "128k", "-ar", "44100", "-movflags", "+faststart", str(yol)]
    try:
        subprocess.run(komut, check=True, timeout=900, capture_output=True, text=True)
        return yol
    except subprocess.CalledProcessError as e:
        log.warning("Video üretilemedi: %s", (e.stderr or "")[-400:])
    except Exception as e:
        log.warning("Video üretilemedi: %s", e)
    return None
