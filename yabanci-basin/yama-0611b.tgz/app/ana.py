"""Giriş noktası: zamanlayıcı + panel. `python -m app.ana`"""
import logging
import os

import uvicorn
from apscheduler.schedulers.background import BackgroundScheduler

from . import ayarlar, isleme, kuyruk, vt, yayinci, yetki

logging.basicConfig(level=os.environ.get("YB_LOG", "INFO"), format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("yb")


def _guvenli(ad, f, *a):
    def sar():
        try:
            f(*a)
        except Exception:
            log.exception("%s görevi başarısız", ad)
    return sar


def hizli_hat():
    kuyruk.gonderileri_hazirla(2)  # ses sırası şişmesin
    kuyruk.planla()
    yayinci.yayin_turu()


def tur(katman: str):
    isleme.topla(katman)
    isleme.kumele()


def zamanlayici() -> BackgroundScheduler:
    a = ayarlar.ayar()["toplama"]
    z = BackgroundScheduler(timezone="Europe/Istanbul", job_defaults={"coalesce": True, "max_instances": 1, "misfire_grace_time": 600})
    z.add_job(_guvenli("P1", tur, "P1"), "interval", minutes=a.get("p1_dakika", 30), id="p1")
    z.add_job(_guvenli("P2", tur, "P2"), "interval", minutes=a.get("p2_dakika", 120), id="p2")
    z.add_job(_guvenli("olay", tur, "olay"), "interval", minutes=a.get("p2_dakika", 120), id="olay")
    z.add_job(_guvenli("radar", tur, "radar"), "interval", minutes=a.get("radar_dakika", 60), id="radar")
    # Hızlı hat: yeni küme -> gönderi -> sıra -> yayın, her dakika (önceki tur bitmeden yenisi başlamaz)
    z.add_job(_guvenli("hizli_hat", hizli_hat), "interval", minutes=1, id="hizli_hat", max_instances=1, coalesce=True)
    z.add_job(_guvenli("instagram_jeton", yetki.instagram_jeton), "interval", hours=24, id="ig_jeton")
    z.add_job(_guvenli("temizlik", kuyruk.temizlik), "interval", hours=24, id="temizlik")
    return z


def main():
    vt.kur()
    if not vt.durum_al("canli_v3"):  # 6 Kasım: kalite kontrolüyle sürekli canlı yayın
        with vt.islem() as c:
            c.execute("DELETE FROM durum WHERE anahtar='ayar:kuru_calisma'")
        vt.durum_yaz("canli_v3", True)
    if not vt.durum_al("temizlik_v2"):  # sıkı konu filtresi öncesi hazırlanan gönderiler yayınlanmasın
        with vt.islem() as c:
            c.execute("UPDATE gonderiler SET durum='reddedildi' WHERE durum IN ('taslak','onayli')")
            c.execute("UPDATE kumeler SET durum='eski' WHERE durum='acik'")  # yeni filtreyle gelen haberlerden devam
        vt.durum_yaz("temizlik_v2", True)
    if not vt.durum_al("denetim_v1"):  # 6 Kasım: denetimsiz hazırlanmış (eski/yanlış olabilecek) gönderiler yayınlanmasın
        with vt.islem() as c:
            c.execute("UPDATE gonderiler SET durum='reddedildi' WHERE durum IN ('taslak','onayli')")
        vt.durum_yaz("denetim_v1", True)
    z = zamanlayici()
    z.start()
    # Açılışta hemen bir P1 turu ve radar
    z.add_job(_guvenli("ilk", lambda: (tur("P1"), tur("radar"))), id="ilk")
    from .panel import app
    uvicorn.run(app, host="0.0.0.0", port=int(os.environ.get("YB_PORT", "8088")), log_level="warning")


if __name__ == "__main__":
    main()
