"""Yayın öncesi zorunlu denetim: tazelik, takım adları, sayı/skor tutarlılığı, LLM ile kaynağa uygunluk, ekran görüntüsü.
Herhangi biri tutmazsa gönderi YAYINLANMAZ."""
import difflib
import json
import logging
import re
from datetime import datetime, timedelta, timezone
from io import BytesIO

import httpx

from . import ag, ayarlar

log = logging.getLogger("yb.denetim")

# Süper Lig + sık geçen kulüpler (doğru Türkçe yazım)
EK_KULUPLER = ["Galatasaray", "Fenerbahçe", "Beşiktaş", "Trabzonspor", "Başakşehir", "Konyaspor", "Kasımpaşa", "Göztepe",
               "Samsunspor", "Kayserispor", "Alanyaspor", "Antalyaspor", "Gaziantep", "Kocaelispor", "Gençlerbirliği", "Rizespor",
               "Eyüpspor", "Karagümrük", "Sivasspor", "Hatayspor", "Adana Demirspor", "Ankaragücü", "Bodrumspor", "Pendikspor",
               "Erzurumspor", "Çorum", "Sakaryaspor", "Bursaspor", "Altay", "Manisa", "Bandırmaspor", "Boluspor", "Ümraniyespor",
               "Amedspor", "Kırklarelispor", "Iğdır", "Keçiörengücü", "Esenler Erokspor", "Sarıyer", "Fatih Karagümrük"]


def kulupler() -> list[str]:
    adlar = [t.get("ad") for t in (ayarlar.terimler().get("takimlar") or {}).values() if t.get("ad")]
    return list(dict.fromkeys(adlar + EK_KULUPLER))


_KELIME = re.compile(r"\b([A-ZÇĞİÖŞÜ][a-zçğıöşüA-ZÇĞİÖŞÜ]{3,})(?=['’]|\b)")
_AILE = ("spor", "saray", "bahçe", "bahce", "paşa", "pasa", "şehir", "sehir", "birliği", "gücü", "tepe", "taş", "tas")


def adlari_duzelt(t: str) -> str:
    """Konjaspor -> Konyaspor, Galatasarai -> Galatasaray, Fenerbahce -> Fenerbahçe (yalnız kulüp adına benzeyen kelimeler)."""
    if not t:
        return t
    adlar = kulupler()
    tek = {a.split()[0]: a.split()[0] for a in adlar}
    def degis(m):
        k = m.group(1)
        if k in tek or not any(e in k.lower() for e in _AILE):
            return k
        yakin = difflib.get_close_matches(k, list(tek), n=1, cutoff=0.78)
        return yakin[0] if yakin else k
    return _KELIME.sub(degis, t)


def bilinmeyen_kulup(t: str) -> list[str]:
    """Kulüp adına benzeyip listede olmayan kelimeler (uydurma/yanlış yazım şüphesi)."""
    tek = {a.split()[0] for a in kulupler()}
    return [k for k in _KELIME.findall(t or "") if k.lower().endswith(("spor", "saray")) and k not in tek]


# ---------------------------------------------------------------- sayılar / skor
_SKOR = re.compile(r"(\d{1,2})\s*[-–:]\s*(\d{1,2})")


def sayilar_tutarli(tr: str, kaynak: str) -> tuple[bool, str]:
    kaynak_sayi = set(re.findall(r"\d+", kaynak or ""))
    kaynak_skor = {tuple(sorted(m)) for m in _SKOR.findall(kaynak or "")}
    for a, b in _SKOR.findall(tr or ""):
        if tuple(sorted((a, b))) not in kaynak_skor:
            return False, f"skor {a}-{b} kaynakta yok"
    temiz = _SKOR.sub(" ", tr or "")
    temiz = re.sub(r"\b(19|20)\d{2}\b", " ", temiz)  # yıllar
    for s in re.findall(r"\d+", temiz):
        if s not in kaynak_sayi:
            return False, f"sayı {s} kaynakta yok"
    return True, ""


# ---------------------------------------------------------------- tazelik
_TARIH_ANAHTAR = ("article:published_time", "og:published_time", "datePublished", "pubdate", "publishdate", "date",
                  "dc.date", "dc.date.issued", "sailthru.date", "parsely-pub-date")


def _iso(s: str) -> datetime | None:
    s = (s or "").strip()
    try:
        d = datetime.fromisoformat(s.replace("Z", "+00:00"))
        return d if d.tzinfo else d.replace(tzinfo=timezone.utc)
    except ValueError:
        m = re.match(r"(\d{4}-\d{2}-\d{2})", s)
        return datetime.fromisoformat(m.group(1)).replace(tzinfo=timezone.utc) if m else None


def yayin_tarihi(url: str, html: str | None = None) -> datetime | None:
    """Sayfanın ilk yayın tarihi (meta etiketleri / JSON-LD datePublished). En eskisini döndürür."""
    if not url or "news.google.com" in url:
        return None
    try:
        html = html if html is not None else ag.getir(url, kosullu=False).metin
    except Exception:
        return None
    adaylar = []
    for anahtar in _TARIH_ANAHTAR:
        for m in re.finditer(r'<meta[^>]+(?:property|name|itemprop)=["\']' + re.escape(anahtar) + r'["\'][^>]*>', html, re.I):
            c = re.search(r'content=["\']([^"\']+)', m.group(0))
            if c and (d := _iso(c.group(1))):
                adaylar.append(d)
    for m in re.finditer(r'"datePublished"\s*:\s*"([^"]+)"', html):
        if d := _iso(m.group(1)):
            adaylar.append(d)
    for m in re.finditer(r'<time[^>]+datetime=["\']([^"\']+)', html, re.I):
        if d := _iso(m.group(1)):
            adaylar.append(d)
    adaylar = [d for d in adaylar if d.year >= 2000]
    return min(adaylar) if adaylar else None


def taze_mi(link: str, haber: dict) -> tuple[bool, str]:
    saat = ayarlar.ayar()["toplama"].get("haber_yasi_saat", 48)
    sinir = datetime.now(timezone.utc) - timedelta(hours=saat)
    sayfa = yayin_tarihi(link)
    if sayfa:
        return (sayfa >= sinir, f"sayfa tarihi {sayfa:%Y-%m-%d %H:%M}")
    # sayfada tarih yok: toplayıcı gerçek tarih verdiyse (zaman != toplanma) ona güven
    z, t = haber.get("zaman") or "", haber.get("toplanma") or ""
    if z and t and z[:16] != t[:16]:
        d = _iso(z)
        return (bool(d and d >= sinir), f"kaynak tarihi {z[:16]}")
    return False, "yayın tarihi bulunamadı"


# ---------------------------------------------------------------- ekran görüntüsü
def ekran_gecerli(veri: bytes | None) -> bool:
    """Boş/beyaz sayfa ya da çok küçük görüntü değil mi?"""
    if not veri or len(veri) < 30_000:
        return False
    try:
        from PIL import Image, ImageStat
        with Image.open(BytesIO(veri)) as im:
            g = im.convert("L").resize((108, 135))
            return ImageStat.Stat(g).stddev[0] > 18
    except Exception:
        return False


# ---------------------------------------------------------------- LLM ile kaynağa uygunluk
DOGRULA = """Sen titiz bir spor editörüsün. Aşağıda yabancı bir haberin KAYNAK metni ve ondan yazılmış TÜRKÇE metin var.
Türkçe metni kaynakla karşılaştır. Şunlardan BİRİ bile varsa "dogru": false ver:
- skor, sonuç (kim kazandı/kaybetti), sayı, tarih kaynakla çelişiyor ya da kaynakta yok
- takım, oyuncu, lig, ülke, şehir adı yanlış ya da kaynakta olmayan bir bilgi eklenmiş
- takım adı yanlış yazılmış (ör. Konjaspor yerine Konyaspor olmalı)
- haber kaynakta eski bir olay olarak anlatılırken Türkçede yeniymiş gibi sunulmuş
Yalnızca JSON döndür: {"dogru": true|false, "hatalar": ["..."]}"""


def llm_uygun(kaynak: str, tr: dict) -> tuple[bool, str]:
    anahtar = ayarlar.ortam("GROQ_API_KEY")
    if not anahtar:
        return False, "doğrulama modeli yok"
    a = ayarlar.ayar()["llm"]
    govde = {"baslik": tr.get("baslik"), "ozet": tr.get("ozet"), "seslendirme": tr.get("seslendirme")}
    try:
        r = httpx.post("https://api.groq.com/openai/v1/chat/completions", timeout=90,
                       headers={"Authorization": f"Bearer {anahtar}"},
                       json={"model": ayarlar.ortam("GROQ_MODEL") or a.get("groq_model", "llama-3.3-70b-versatile"),
                             "temperature": 0, "response_format": {"type": "json_object"},
                             "messages": [{"role": "system", "content": DOGRULA},
                                          {"role": "user", "content": "KAYNAK:\n" + kaynak[:4000] + "\n\nTÜRKÇE:\n"
                                           + json.dumps(govde, ensure_ascii=False)}]})
        r.raise_for_status()
        v = json.loads(r.json()["choices"][0]["message"]["content"])
        return bool(v.get("dogru")), "; ".join(map(str, v.get("hatalar") or []))[:300]
    except Exception as e:
        return False, f"doğrulama hatası: {e}"


def metni_duzelt(sonuc: dict) -> dict:
    for k in ("baslik", "ozet", "metin", "kisa_metin", "video_basligi", "seslendirme"):
        if isinstance(sonuc.get(k), str):
            sonuc[k] = adlari_duzelt(sonuc[k])
    return sonuc


def icerik_denetle(sonuc: dict, kaynak: str) -> tuple[bool, str]:
    """Takım adı, sayı/skor ve LLM kontrolü. (tamam, neden)"""
    tr = " ".join(str(sonuc.get(k) or "") for k in ("baslik", "ozet", "seslendirme"))
    if b := bilinmeyen_kulup(tr):
        return False, f"tanınmayan kulüp adı: {', '.join(b)}"
    ok, neden = sayilar_tutarli(tr, kaynak)
    if not ok:
        return False, neden
    return llm_uygun(kaynak, sonuc)
